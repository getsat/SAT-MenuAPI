using Microsoft.AspNetCore.Mvc;
using SATMenuAPI.Models;

namespace SATMenuAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class MenusController : ControllerBase
    {
        private static List<Menu> menus = new List<Menu>
        {
            new Menu { Id = 1, Nom = "Poulet DG", Description = "Délicieux plat camerounais", Prix = 3500 },
            new Menu { Id = 2, Nom = "Ndolé", Description = "Plat traditionnel aux feuilles amères", Prix = 3000 }
        };

        [HttpGet]
        public ActionResult<IEnumerable<Menu>> GetMenus()
        {
            return Ok(menus);
        }

        [HttpPost]
        public ActionResult<Menu> CreateMenu(Menu menu)
        {
            menu.Id = menus.Count + 1;
            menus.Add(menu);
            return CreatedAtAction(nameof(GetMenus), new { id = menu.Id }, menu);
        }
    }
}
